const evidancemanagement = artifacts.require("evidancemanagement");

module.exports = function(deployer) {
  deployer.deploy(evidancemanagement);
};