from flask import Flask, request, render_template, jsonify
from web3 import Web3, HTTPProvider
import json
import urllib3

app = Flask(__name__)

blockchain = 'http://127.0.0.1:7545'

# Function to connect to the blockchain and contract
def connect():
    web3 = Web3(HTTPProvider(blockchain))
    web3.eth.defaultAccount = web3.eth.accounts[0]

    artifact = "../build/contracts/EvidanceManagement.json"
    with open(artifact) as f:
        artifact_json = json.load(f)
        contract_abi = artifact_json['abi']
        contract_address = artifact_json['networks']['5777']['address']

    contract = web3.eth.contract(
        abi=contract_abi,
        address=contract_address
    )
    return contract, web3

@app.route('/', methods=['GET'])
def home():
    return render_template('home.html')

@app.route('/addevidance', methods=['GET'])
def add_evidance_page():
    return render_template('addevidance.html')

@app.route('/verifyevidance', methods=['GET'])
def verify_evidance_page():
    return render_template('verifyevidance.html')

@app.route('/addEvidance', methods=['GET', 'POST'])
def add_evidance():
    try:
        name = request.args.get('name')
        age = int(request.args.get('age'))
        evidence = request.args.get('evidence')

        if not name or not evidence:
            return "Name and evidence are required.", 400

        contract, web3 = connect()
        tx_hash = contract.functions.setEvidance(name, age, evidence).transact()
        web3.eth.waitForTransactionReceipt(tx_hash)
        return 'Evidence Added Successfully'
    except Exception as e:
        return f'Transaction Error: {str(e)}', 500

@app.route('/addevidanceform', methods=['POST'])
def add_evidance_form():
    name = request.form['name']
    age = request.form['age']
    evidence = request.form['evidence']
    
    # Send request to add evidence to the blockchain
    pipe = urllib3.PoolManager()
    response = pipe.request('GET', f'http://127.0.0.1:4000/addEvidance?name={name}&age={age}&evidence={evidence}')
    response_message = response.data.decode('utf-8')
    
    return render_template('addevidance.html', add_response=response_message)

@app.route('/verifyEvidance', methods=['GET'])
def verify_evidance():
    person_address = request.args.get('address')
    
    contract, web3 = connect()
    try:
        record = contract.functions.getEvidance(person_address).call()
        return jsonify({
            'name': record[0],
            'age': record[1],
            'evidence': record[2],
        })
    except Exception as e:
        return jsonify({'error': str(e)})

@app.route('/verifyevidanceform', methods=['POST'])
def verify_evidance_form():
    person_address = request.form['address']
    
    pipe = urllib3.PoolManager()
    response = pipe.request('GET', f'http://127.0.0.1:4000/verifyEvidance?address={person_address}')
    response_data = response.data.decode('utf-8')
    
    try:
        record = json.loads(response_data)
        return render_template('verifyevidance.html', identity_record=record)
    except json.JSONDecodeError:
        return render_template('verifyevidance.html', verify_response='Record not found or invalid address.')

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=4000)
